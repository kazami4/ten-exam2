require('../../common/welcome')('semantic')
